package org.github.flytreeleft.nexus3.keycloak.plugin.internal.http;

public interface ClientAuthenticator {

    void configure(HttpMethod httpMethod);
}
